/****
*  charutl.h
*
*  Writen By Xilong Pei , 1998
****************************************************************************/

#ifndef __CHARUTL_H__

char *strGetChar( char *s, char *cp );

#endif