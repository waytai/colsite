/////////////////
// ASQL_Optimize_config program: ASQL_OPT.H
//
// copyright (c) 2000 Xilong Pei
//
/////////////////////////////////////////////////////////////////////////////

#ifndef __ASQL_OPT_H__
#define __ASQL_OPT_H__

short setASQLShortOptPara( int i, short w );
long setASQLLongOptPara( int i, long L);


#endif

