/****************
*  ParaBrk.H
*  author: Richard.J
*
*  copyright (c) Shanghai Tiedao University MIS Research, 1996
****************************************************************************/

#ifndef __STRBREAK_H
#define __STRBREAK_H

char **paraBreak( const char *str1, const char *str2, int *strNum );

#endif
