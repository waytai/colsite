/****
*  arrayutl.H
*
*  Writen By Xilong Pei , 1995.5.4
****************************************************************************/

#ifndef __ARRAYUTL_H__
#define __ARRAYUTL_H__


short *arrayUnion(short *art, short *ars, short num);
short iarrayShort( short *array, short num, short digit );


#endif