/****************
* str_gram.h
* 1999.5.19
*
* ^-_-^ Xilong Pei
****************************************************************************/

#ifndef __STR_GRAM_H__
#define __STR_GRAM_H__

char *locateKeywordInBuf(char *sz, char *szkey, char *szFollowKey, int ibufsize);

#endif