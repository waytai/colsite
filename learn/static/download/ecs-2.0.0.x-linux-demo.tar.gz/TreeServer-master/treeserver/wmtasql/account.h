/******************************
*	Module Name:
*		ACCOUNT.H
*
*	Abstract:
*
*	Author:
*		NiuJingyu.
*
*	Copyright (c) 1997  China Railway Software Corporation
*
*	Revision History:
*		Write by NiuJingyu, 1997.10
********************************************************************************/
#ifndef _INC_ACCOUNT_
#define _INC_ACCOUNT_

BOOL GetUserHomeDir ( LPCSTR lpServer, LPCSTR lpUserName, LPSTR lpHomeDir );

#endif // _INC_ACCOUNT_