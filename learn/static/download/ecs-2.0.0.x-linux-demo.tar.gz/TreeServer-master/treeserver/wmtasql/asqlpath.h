/****************
 * asqlpath.h
 *
 * Copyright (c) CRSC 1998
 *
 ****************************************************************************/

#ifndef __ASQLPATH_H__
#define __ASQLPATH_H__

char *szAsqlPath( char *oPath, char *szAsqlPath );

#endif