/****************
* syscall.h
* 1995.4.20
*****************************************************************************/

#ifndef __SYSCALL_H__
#define __SYSCALL_H__


int systemCall(const char *command);


#endif
