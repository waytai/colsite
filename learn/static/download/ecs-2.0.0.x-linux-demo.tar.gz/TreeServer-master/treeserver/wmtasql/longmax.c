main()
{
printf("%ld\n", 0x7FFFFFFF);
}