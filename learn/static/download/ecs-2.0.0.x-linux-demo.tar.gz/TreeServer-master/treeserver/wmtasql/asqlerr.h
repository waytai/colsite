/***************************************************************************\
 * ASQLANA.H
 * Author: LianChun Song    1994.6
 *
 * Copyright: East-Union Computer Service Co., Ltd. 1994
\***************************************************************************/

char *AsqlErrorMes( void );
    /*
    return the error message occured in the asqlana
    */