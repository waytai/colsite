/*********
 * dbs_util.h
 * author:  Xilong Pei
 ****************************************************************************/


#ifndef  __DBS_UTIL_H__
#define  __DBS_UTIL_H__

int buildDatabase(char *parameter);
int dropDatabase(char *parameter);

#endif

