//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Notify1.rc
//
#define IDD_NOTIFY                      101
#define IDD_ABOUTBOX                    102
#define IDR_MENU                        103
#define POPUPMENU                       105
#define LightOnIcon                     106
#define LightOffIcon                    107
#define IDD_SERVERDIALOG                108
#define IDB_BITMAPRUN                   110
#define IDI_ICONRUN                     111
#define IDI_ICONPAUSE                   112
#define IDI_ICONSTOP                    113
#define IDC_LIGHTNOTIFYICON             1000
#define IDC_ADD                         1001
#define IDC_DEL                         1002
#define IDC_DELETE                      1002
#define IDC_CHANGE                      1003
#define IDC_ICONLIGHTOFF                1004
#define IDC_ICONLIGHTON                 1005
#define IDC_START                       1006
#define IDC_PAUSE                       1007
#define IDC_START3                      1008
#define IDC_STATICINFO                  1009
#define IDC_LIGHT                       40001
#define IDM_EXIT                        40003
#define ID_MENUITEM40004                40004
#define IDM_ABOUT                       40005
#define ID_MENUITEM40006                40006
#define IDM_SHOWDLGBOX                  40007
#define ID_PAUSE                        40010

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        114
#define _APS_NEXT_COMMAND_VALUE         40011
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
