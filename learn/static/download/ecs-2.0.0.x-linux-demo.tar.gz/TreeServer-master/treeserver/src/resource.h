//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TreeSvr.rc
//
#define IDD_ABOUTBOX                    102
#define IDB_BITMAPBLANK                 104
#define POPUPMENU                       105
#define IDB_BITMAPPAUSE                 105
#define IDB_BITMAPSTOP                  106
#define IDD_SERVERDIALOG                108
#define IDI_ICONBLANK                   108
#define IDB_BITMAPRUN                   110
#define IDI_ICONRUN                     111
#define IDI_ICONPAUSE                   112
#define IDI_ICONSTOP                    113
#define IDC_STATELINE                   1002
#define IDC_START                       1006
#define IDC_PAUSE                       1007
#define IDC_STOP                        1008
#define IDM_SHOW                        40001
#define IDM_ABOUT                       40002
#define IDM_EXIT                        40003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        111
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
