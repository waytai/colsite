// By jingyu Niu 1999.09
// Support plug-ins to access TreeServer resource

typedef 
typedef tagTInterface {


} TInterface, PTInterface, LPTInterface;