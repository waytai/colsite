#ifndef __TERMCK_H__
#define __TERMCK_H__

#ifndef TERMFILE
#define TERMFILE	"trial"
#endif /* TERMFILE */

int trialbuild ( int days, char *path );
int trialck ( void );

#endif /* __TERMCK_H__ */